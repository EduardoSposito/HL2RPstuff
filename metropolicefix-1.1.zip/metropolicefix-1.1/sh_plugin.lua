PLUGIN.name = "MetropolicePack Fix for 1.1"
PLUGIN.author = "NexusGamer"
PLUGIN.desc = "Fixes the animations for the metropolice pack."

nut.anim.setModelClass("models/dpfilms/metropolice/civil_medic.mdl", "metrocop")
nut.anim.setModelClass("models/dpfilms/metropolice/hdpolice.mdl", "metrocop")
nut.anim.setModelClass("models/dpfilms/metropolice/female_police.mdl", "metrocop")
nut.anim.setModelClass("models/dpfilms/metropolice/hl2concept.mdl", "metrocop")
nut.anim.setModelClass("models/dpfilms/metropolice/urban_police.mdl","metrocop")
nut.anim.setModelClass("models/dpfilms/metropolice/resistance_police.mdl", "metrocop")
nut.anim.setModelClass("models/dpfilms/metropolice/retrocop.mdl", "metrocop")
--If u need to add + models just ctrl c and ctrl v and change the models the easy way :)